// ── WMO codes ────────────────────────────────────────────
const CONDITIONS = {
  0:  { icon: '☀️',  label: 'Clear sky' },
  1:  { icon: '🌤️', label: 'Mainly clear' },
  2:  { icon: '⛅',  label: 'Partly cloudy' },
  3:  { icon: '☁️',  label: 'Overcast' },
  45: { icon: '🌫️', label: 'Foggy' },
  48: { icon: '🌫️', label: 'Icy fog' },
  51: { icon: '🌦️', label: 'Light drizzle' },
  53: { icon: '🌦️', label: 'Drizzle' },
  55: { icon: '🌧️', label: 'Heavy drizzle' },
  61: { icon: '🌧️', label: 'Light rain' },
  63: { icon: '🌧️', label: 'Rain' },
  65: { icon: '🌧️', label: 'Heavy rain' },
  71: { icon: '🌨️', label: 'Light snow' },
  73: { icon: '🌨️', label: 'Snow' },
  75: { icon: '❄️',  label: 'Heavy snow' },
  77: { icon: '🌨️', label: 'Snow grains' },
  80: { icon: '🌦️', label: 'Rain showers' },
  81: { icon: '🌧️', label: 'Heavy showers' },
  82: { icon: '⛈️', label: 'Violent showers' },
  85: { icon: '🌨️', label: 'Snow showers' },
  86: { icon: '🌨️', label: 'Heavy snow showers' },
  95: { icon: '⛈️', label: 'Thunderstorm' },
  96: { icon: '⛈️', label: 'Thunderstorm + hail' },
  99: { icon: '⛈️', label: 'Severe thunderstorm' },
};

function getCondition(code) {
  return CONDITIONS[code] || { icon: '🌡️', label: 'Unknown' };
}

// ── State ────────────────────────────────────────────────
let useCelsius = true;

// ── Clock ────────────────────────────────────────────────
function updateClock() {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  document.getElementById('clock').textContent = `${h}:${m}`;

  const days   = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const months = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];
  document.getElementById('date-day').textContent  = days[now.getDay()];
  document.getElementById('date-full').textContent =
    `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
}
setInterval(updateClock, 1000);
updateClock();

// ── Settings button ──────────────────────────────────────
document.getElementById('settings-btn').addEventListener('click', () => {
  window.location.href = 'settings.html';
});

// ── Render ───────────────────────────────────────────────
function renderWeather(data, prefs) {
  const cur  = data.current;
  const cond = getCondition(cur.weather_code);

  document.getElementById('weather-icon-large').textContent = cond.icon;
  document.getElementById('condition').textContent          = cond.label;
  document.getElementById('humidity').textContent           = `${Math.round(cur.relative_humidity_2m)}%`;
  document.getElementById('location').textContent           = prefs.locationName;

  const card = document.getElementById('current-card');
  card.dataset.tempC   = Math.round(cur.temperature_2m);
  card.dataset.feelsC  = Math.round(cur.apparent_temperature);
  card.dataset.windKmh = Math.round(cur.wind_speed_10m);

  renderForecast(data.daily);
  updateUnits();
}

function renderForecast(daily) {
  const strip    = document.getElementById('forecast-strip');
  strip.innerHTML = '';
  const dayNames  = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  for (let i = 1; i <= 3; i++) {
    if (!daily.time[i]) continue;
    const date  = new Date(daily.time[i] + 'T12:00:00');
    const cond  = getCondition(daily.weather_code[i]);
    const highC = Math.round(daily.temperature_2m_max[i]);
    const lowC  = Math.round(daily.temperature_2m_min[i]);

    const col = document.createElement('div');
    col.className     = 'forecast-day glass';
    col.dataset.highC = highC;
    col.dataset.lowC  = lowC;
    col.innerHTML = `
      <span class="forecast-day-name">${dayNames[date.getDay()]}</span>
      <span class="forecast-day-icon">${cond.icon}</span>
      <span class="forecast-high">--</span>
      <span class="forecast-low">--</span>`;
    strip.appendChild(col);
  }

  updateForecastUnits();
}

// ── Units ────────────────────────────────────────────────
function updateUnits() {
  const card    = document.getElementById('current-card');
  const tempC   = parseInt(card.dataset.tempC   || '0');
  const feelsC  = parseInt(card.dataset.feelsC  || '0');
  const windKmh = parseInt(card.dataset.windKmh || '0');

  if (useCelsius) {
    document.getElementById('temperature').textContent = tempC;
    document.getElementById('temp-unit').textContent   = '°C';
    document.getElementById('feels-like').textContent  = `${feelsC}°C`;
    document.getElementById('wind').textContent        = `${windKmh} km/h`;
  } else {
    document.getElementById('temperature').textContent = toF(tempC);
    document.getElementById('temp-unit').textContent   = '°F';
    document.getElementById('feels-like').textContent  = `${toF(feelsC)}°F`;
    document.getElementById('wind').textContent        = `${toMph(windKmh)} mph`;
  }

  updateForecastUnits();
}

function updateForecastUnits() {
  document.querySelectorAll('.forecast-day').forEach(col => {
    const highC = parseInt(col.dataset.highC);
    const lowC  = parseInt(col.dataset.lowC);
    col.querySelector('.forecast-high').textContent = useCelsius ? `${highC}°` : `${toF(highC)}°`;
    col.querySelector('.forecast-low').textContent  = useCelsius ? `${lowC}°`  : `${toF(lowC)}°`;
  });
}

function toF(c)   { return Math.round(c * 9/5 + 32); }
function toMph(k) { return Math.round(k * 0.621371); }

// ── Fetch weather ─────────────────────────────────────────
async function fetchWeather(prefs) {
  const { lat, lon } = prefs;
  const url =
    `https://api.open-meteo.com/v1/forecast` +
    `?latitude=${lat}&longitude=${lon}` +
    `&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code` +
    `&daily=temperature_2m_max,temperature_2m_min,weather_code` +
    `&wind_speed_unit=kmh&timezone=auto&forecast_days=4`;

  const res  = await fetch(url);
  if (!res.ok) throw new Error(`API ${res.status}`);
  return res.json();
}

// ── Boot ─────────────────────────────────────────────────
chrome.storage.local.get('skyline_prefs', async (result) => {
  const prefs = result.skyline_prefs;

  // No setup done yet → redirect to setup
  if (!prefs || !prefs.lat) {
    window.location.href = 'setup.html';
    return;
  }

  // Apply saved unit preference
  useCelsius = (prefs.unit !== 'F');

  // Check for cached weather data (valid for 30 mins)
  const CACHE_TTL = 30 * 60 * 1000;
  const cached = result.skyline_prefs._cache;

  if (cached && Date.now() - cached.ts < CACHE_TTL) {
    // Render instantly from cache
    renderWeather(cached.data, prefs);
  }

  // Always fetch fresh in background (silently)
  try {
    const data = await fetchWeather(prefs);
    renderWeather(data, prefs);

    // Save cache back into prefs
    prefs._cache = { data, ts: Date.now() };
    chrome.storage.local.set({ skyline_prefs: prefs });
  } catch (err) {
    // If we already rendered from cache, silently fail
    // If no cache, show a soft error in the location field
    if (!cached) {
      document.getElementById('location').textContent = 'Could not load weather — check connection';
    }
    console.error('Weather fetch failed:', err);
  }
});
