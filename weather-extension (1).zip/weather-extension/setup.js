let pendingLocation = null;
let selectedUnit = 'C';

// ── View switching ────────────────────────────────────────
function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function setProgress(step) {
  ['dot-1', 'dot-2', 'dot-3'].forEach((id, i) => {
    const dot = document.getElementById(id);
    dot.className = 'progress-dot';
    if (i + 1 < step)  dot.classList.add('done');
    if (i + 1 === step) dot.classList.add('active');
  });
}

// ── GPS ───────────────────────────────────────────────────
document.getElementById('use-gps-btn').addEventListener('click', () => {
  showView('view-loading');
  document.getElementById('loading-msg').textContent = 'Requesting location…';
  setProgress(1);

  navigator.geolocation.getCurrentPosition(
    async (pos) => {
      setProgress(2);
      document.getElementById('loading-msg').textContent = 'Resolving city name…';
      const { latitude: lat, longitude: lon } = pos.coords;
      const name = await reverseGeocode(lat, lon);
      setProgress(3);
      pendingLocation = { lat, lon, locationName: name };
      showView('view-units');
    },
    () => {
      document.getElementById('city-error').textContent =
        'Location access was denied — please enter a city instead.';
      showView('view-city');
      document.getElementById('city-input').focus();
    },
    { timeout: 10000 }
  );
});

// ── City entry ────────────────────────────────────────────
document.getElementById('use-city-btn').addEventListener('click', () => {
  showView('view-city');
  document.getElementById('city-input').focus();
});

document.getElementById('back-btn').addEventListener('click', () => {
  showView('view-method');
});

async function submitCity() {
  const city = document.getElementById('city-input').value.trim();
  if (!city) return;

  document.getElementById('city-error').textContent = '';
  document.getElementById('city-submit-btn').textContent = '…';
  document.getElementById('city-submit-btn').disabled = true;

  showView('view-loading');
  document.getElementById('loading-msg').textContent = `Looking up "${city}"…`;
  setProgress(1);

  try {
    const res = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`
    );
    const data = await res.json();

    if (!data.results || data.results.length === 0) {
      document.getElementById('city-error').textContent = `"${city}" not found — try another name.`;
      document.getElementById('city-submit-btn').textContent = 'Search';
      document.getElementById('city-submit-btn').disabled = false;
      showView('view-city');
      return;
    }

    setProgress(3);
    const { latitude: lat, longitude: lon, name, country } = data.results[0];
    pendingLocation = { lat, lon, locationName: `${name}, ${country}` };
    document.getElementById('city-submit-btn').textContent = 'Search';
    document.getElementById('city-submit-btn').disabled = false;
    showView('view-units');

  } catch {
    document.getElementById('city-error').textContent = 'Search failed — check your connection.';
    document.getElementById('city-submit-btn').textContent = 'Search';
    document.getElementById('city-submit-btn').disabled = false;
    showView('view-city');
  }
}

document.getElementById('city-submit-btn').addEventListener('click', submitCity);
document.getElementById('city-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') submitCity();
});

// ── Units ─────────────────────────────────────────────────
document.querySelectorAll('.unit-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.unit-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selectedUnit = btn.dataset.unit;
  });
});

// ── Finish ────────────────────────────────────────────────
document.getElementById('finish-btn').addEventListener('click', () => {
  if (!pendingLocation) {
    showView('view-method');
    return;
  }

  const prefs = {
    lat:          pendingLocation.lat,
    lon:          pendingLocation.lon,
    locationName: pendingLocation.locationName,
    unit:         selectedUnit
  };

  chrome.storage.local.set({ skyline_prefs: prefs }, () => {
    if (chrome.runtime.lastError) {
      console.error('Storage error:', chrome.runtime.lastError);
      return;
    }
    window.location.href = 'newtab.html';
  });
});

// ── Reverse geocode ───────────────────────────────────────
async function reverseGeocode(lat, lon) {
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`,
      { headers: { 'Accept-Language': 'en' } }
    );
    const data = await res.json();
    const a = data.address;
    return a.city || a.town || a.village || a.county || 'Your location';
  } catch {
    return 'Your location';
  }
}
