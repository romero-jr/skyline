let prefs = {};

// ── Load prefs ────────────────────────────────────────────
chrome.storage.local.get('skyline_prefs', (result) => {
  prefs = result.skyline_prefs || {};

  document.getElementById('location-name').textContent = prefs.locationName || '—';
  document.getElementById('location-coords').textContent =
    prefs.lat ? `${prefs.lat.toFixed(3)}, ${prefs.lon.toFixed(3)}` : '';

  document.querySelectorAll('.unit-btn').forEach(btn => {
    btn.classList.toggle('selected', btn.dataset.unit === (prefs.unit || 'C'));
  });
});

// ── Units ─────────────────────────────────────────────────
document.querySelectorAll('.unit-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.unit-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    prefs.unit = btn.dataset.unit;
  });
});

// ── Change city ───────────────────────────────────────────
document.getElementById('change-city-btn').addEventListener('click', () => {
  document.getElementById('city-change-row').classList.add('visible');
  document.getElementById('change-city-btn').style.display = 'none';
  document.getElementById('city-input').focus();
});

async function submitCity() {
  const city = document.getElementById('city-input').value.trim();
  if (!city) return;

  document.getElementById('city-error').textContent = '';
  document.getElementById('city-submit-btn').textContent = '…';
  document.getElementById('city-submit-btn').disabled = true;

  try {
    const res = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`
    );
    const data = await res.json();

    if (!data.results || data.results.length === 0) {
      document.getElementById('city-error').textContent = `"${city}" not found.`;
      document.getElementById('city-submit-btn').textContent = 'Save';
      document.getElementById('city-submit-btn').disabled = false;
      return;
    }

    const { latitude: lat, longitude: lon, name, country } = data.results[0];
    prefs.lat          = lat;
    prefs.lon          = lon;
    prefs.locationName = `${name}, ${country}`;
    delete prefs._cache;

    document.getElementById('location-name').textContent   = prefs.locationName;
    document.getElementById('location-coords').textContent = `${lat.toFixed(3)}, ${lon.toFixed(3)}`;
    document.getElementById('city-change-row').classList.remove('visible');
    document.getElementById('change-city-btn').style.display = 'inline-block';
    document.getElementById('city-submit-btn').textContent = 'Save';
    document.getElementById('city-submit-btn').disabled = false;
    showSaveMsg('Location updated — click Save changes to confirm.');

  } catch {
    document.getElementById('city-error').textContent = 'Search failed — check your connection.';
    document.getElementById('city-submit-btn').textContent = 'Save';
    document.getElementById('city-submit-btn').disabled = false;
  }
}

document.getElementById('city-submit-btn').addEventListener('click', submitCity);
document.getElementById('city-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') submitCity();
});

// ── Save ──────────────────────────────────────────────────
document.getElementById('save-btn').addEventListener('click', () => {
  chrome.storage.local.set({ skyline_prefs: prefs }, () => {
    if (chrome.runtime.lastError) {
      console.error('Storage error:', chrome.runtime.lastError);
      return;
    }
    showSaveMsg('Saved ✓');
    setTimeout(() => { window.location.href = 'newtab.html'; }, 700);
  });
});

// ── Reset ─────────────────────────────────────────────────
document.getElementById('reset-btn').addEventListener('click', () => {
  if (!confirm('Clear all Skyline data and re-run setup?')) return;
  chrome.storage.local.remove(['skyline_prefs', 'skyline_calendar'], () => {
    window.location.href = 'setup.html';
  });
});

// ── Close ─────────────────────────────────────────────────
document.getElementById('close-btn').addEventListener('click', () => {
  window.location.href = 'newtab.html';
});

// ── Helper ────────────────────────────────────────────────
function showSaveMsg(msg) {
  const el = document.getElementById('save-msg');
  el.textContent = msg;
  setTimeout(() => { el.textContent = ''; }, 3000);
}

// ── Calendar disconnect ───────────────────────────────────
const disconnectBtn = document.getElementById('calendar-disconnect-btn');
if (disconnectBtn) {
  chrome.storage.local.get('skyline_calendar', (result) => {
    if (result.skyline_calendar && result.skyline_calendar.icalUrl) {
      disconnectBtn.style.display = 'inline-block';
    }
  });

  disconnectBtn.addEventListener('click', () => {
    chrome.storage.local.remove('skyline_calendar', () => {
      disconnectBtn.style.display = 'none';
      showSaveMsg('Calendar disconnected.');
    });
  });
}
