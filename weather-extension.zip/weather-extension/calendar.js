// ── iCal Calendar ─────────────────────────────────────────
// Fetches a Google Calendar iCal feed, parses today's events,
// and renders them in the calendar tile.

const CAL_KEY = 'skyline_calendar';

// ── Boot ──────────────────────────────────────────────────
chrome.storage.local.get(CAL_KEY, (result) => {
  const cal = result[CAL_KEY];

  if (cal && cal.icalUrl) {
    document.getElementById('calendar-connect-btn').textContent = 'Refresh';
    fetchAndRenderEvents(cal.icalUrl);
  } else {
    setCalendarState('disconnected');
  }
});

// ── Connect / Refresh button ──────────────────────────────
document.getElementById('calendar-connect-btn').addEventListener('click', () => {
  chrome.storage.local.get(CAL_KEY, (result) => {
    const cal = result[CAL_KEY];
    if (cal && cal.icalUrl) {
      fetchAndRenderEvents(cal.icalUrl);
    } else {
      // Prompt for iCal URL
      showIcalInput();
    }
  });
});

// ── Show iCal input ───────────────────────────────────────
function showIcalInput() {
  const container = document.getElementById('calendar-events');
  container.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:6px;width:100%">
      <input
        id="ical-url-input"
        type="text"
        placeholder="Paste iCal URL from Google Calendar…"
        style="
          background:rgba(255,255,255,0.07);
          border:1px solid rgba(255,255,255,0.14);
          color:#fff;
          font-family:Inter,sans-serif;
          font-size:11px;
          padding:8px 12px;
          border-radius:8px;
          outline:none;
          width:100%;
          box-sizing:border-box;
        "
      />
      <div style="display:flex;gap:6px;">
        <button id="ical-save-btn" style="
          flex:1;
          background:rgba(255,255,255,0.1);
          border:1px solid rgba(255,255,255,0.18);
          color:rgba(255,255,255,0.85);
          font-family:Inter,sans-serif;
          font-size:10px;
          font-weight:600;
          letter-spacing:0.08em;
          text-transform:uppercase;
          padding:7px;
          border-radius:8px;
          cursor:pointer;
        ">Save</button>
        <button id="ical-cancel-btn" style="
          background:none;
          border:1px solid rgba(255,255,255,0.08);
          color:rgba(255,255,255,0.3);
          font-family:Inter,sans-serif;
          font-size:10px;
          font-weight:600;
          letter-spacing:0.08em;
          text-transform:uppercase;
          padding:7px 10px;
          border-radius:8px;
          cursor:pointer;
        ">Cancel</button>
      </div>
      <span id="ical-error" style="font-size:10px;color:rgba(255,100,100,0.8);min-height:12px;"></span>
    </div>`;

  document.getElementById('ical-url-input').focus();

  document.getElementById('ical-save-btn').addEventListener('click', saveIcalUrl);
  document.getElementById('ical-cancel-btn').addEventListener('click', () => {
    setCalendarState('disconnected');
  });
  document.getElementById('ical-url-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') saveIcalUrl();
  });
}

async function saveIcalUrl() {
  const url = document.getElementById('ical-url-input').value.trim();
  if (!url) return;

  if (!url.includes('calendar.google.com') && !url.endsWith('.ics')) {
    document.getElementById('ical-error').textContent = 'Please paste a valid iCal URL (.ics)';
    return;
  }

  document.getElementById('ical-save-btn').textContent = '…';

  // Test fetch before saving
  const events = await fetchIcal(url);
  if (events === null) {
    document.getElementById('ical-error').textContent = 'Could not load that URL — check it and try again.';
    document.getElementById('ical-save-btn').textContent = 'Save';
    return;
  }

  // Save and render
  chrome.storage.local.set({ [CAL_KEY]: { icalUrl: url } }, () => {
    document.getElementById('calendar-connect-btn').textContent = 'Refresh';
    renderEvents(events);
  });
}

// ── Fetch + parse iCal ────────────────────────────────────
async function fetchAndRenderEvents(url) {
  setCalendarState('loading');
  const events = await fetchIcal(url);
  if (events === null) {
    setCalendarState('error', 'Could not load calendar.');
  } else {
    renderEvents(events);
  }
}

async function fetchIcal(url) {
  try {
    // Extensions can fetch cross-origin directly via host_permissions
    const res = await fetch(url, { cache: 'no-cache' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    return parseIcal(text);
  } catch (err) {
    console.error('iCal fetch error:', err);
    return null;
  }
}

// ── iCal parser ───────────────────────────────────────────
function parseIcal(text) {
  const events = [];
  const lines  = unfoldLines(text);
  let current  = null;

  for (const line of lines) {
    if (line === 'BEGIN:VEVENT') {
      current = {};
    } else if (line === 'END:VEVENT') {
      if (current) {
        const event = buildEvent(current);
        if (event) events.push(event);
        current = null;
      }
    } else if (current !== null) {
      const sep = line.indexOf(':');
      if (sep === -1) continue;
      const key = line.substring(0, sep).split(';')[0].trim();
      const val = line.substring(sep + 1).trim();
      current[key] = val;
    }
  }

  // Filter to today's events, sort by start time
  const today      = new Date();
  const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const endOfDay   = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59);

  return events
    .filter(e => e.start && e.start >= startOfDay && e.start <= endOfDay)
    .sort((a, b) => a.start - b.start);
}

function unfoldLines(text) {
  // iCal lines can be folded with \r\n + whitespace
  return text
    .replace(/\r\n[ \t]/g, '')
    .replace(/\r\n/g, '\n')
    .split('\n')
    .filter(l => l.trim());
}

function buildEvent(raw) {
  try {
    const summary = (raw['SUMMARY'] || 'Untitled').replace(/\\,/g, ',').replace(/\\n/g, ' ');

    // Parse start — handle both datetime and date-only
    const dtstart = raw['DTSTART'] || raw['DTSTART;VALUE=DATE'] || '';
    const dtend   = raw['DTEND']   || raw['DTEND;VALUE=DATE']   || '';

    // Find keys with parameters (e.g. DTSTART;TZID=America/New_York)
    const startKey = Object.keys(raw).find(k => k.startsWith('DTSTART'));
    const endKey   = Object.keys(raw).find(k => k.startsWith('DTEND'));
    const startVal = startKey ? raw[startKey] : dtstart;
    const endVal   = endKey   ? raw[endKey]   : dtend;

    if (!startVal) return null;

    const start   = parseIcalDate(startVal);
    const end     = endVal ? parseIcalDate(endVal) : null;
    const allDay  = startVal.length === 8; // date-only format YYYYMMDD

    return { summary, start, end, allDay };
  } catch {
    return null;
  }
}

function parseIcalDate(str) {
  // Format: 20240319T140000Z or 20240319T140000 or 20240319
  str = str.replace(/[^0-9TZ]/g, '');
  if (str.length === 8) {
    // Date only: YYYYMMDD
    return new Date(
      parseInt(str.slice(0,4)),
      parseInt(str.slice(4,6)) - 1,
      parseInt(str.slice(6,8))
    );
  }
  // DateTime: YYYYMMDDTHHMMSSZ
  return new Date(
    `${str.slice(0,4)}-${str.slice(4,6)}-${str.slice(6,8)}T${str.slice(9,11)}:${str.slice(11,13)}:${str.slice(13,15)}${str.endsWith('Z') ? 'Z' : ''}`
  );
}

// ── Render ────────────────────────────────────────────────
function renderEvents(events) {
  const container = document.getElementById('calendar-events');
  container.innerHTML = '';

  // Filter out all-day events
  const timed = events.filter(e => !e.allDay);

  if (timed.length === 0) {
    container.innerHTML = '<span class="cal-empty">No events today</span>';
    return;
  }

  const now = new Date();

  timed.slice(0, 5).forEach(event => {
    const isNow  = event.start <= now && event.end && event.end >= now;
    const isPast = event.end ? event.end < now : event.start < now;

    const row = document.createElement('div');
    row.className = 'cal-event' + (isNow ? ' now' : '');
    row.style.opacity = isPast ? '0.4' : '1';

    const timeEl = document.createElement('span');
    timeEl.className   = 'cal-event-time';
    timeEl.textContent = formatTime(event.start);

    const titleEl = document.createElement('span');
    titleEl.className   = 'cal-event-title';
    titleEl.textContent = event.summary;

    row.appendChild(timeEl);
    row.appendChild(titleEl);
    container.appendChild(row);
  });
}

// ── States ────────────────────────────────────────────────
function setCalendarState(state, msg) {
  const container = document.getElementById('calendar-events');
  container.innerHTML = '';

  if (state === 'loading') {
    container.innerHTML = '<span class="cal-empty">Loading…</span>';
  } else if (state === 'disconnected') {
    container.innerHTML = '<span class="cal-empty">Not connected</span>';
    document.getElementById('calendar-connect-btn').textContent = 'Connect →';
  } else if (state === 'error') {
    container.innerHTML = `<span class="cal-error">${msg || 'Something went wrong.'}</span>`;
  }
}

// ── Helpers ───────────────────────────────────────────────
function formatTime(date) {
  const h      = date.getHours();
  const m      = String(date.getMinutes()).padStart(2, '0');
  const suffix = h >= 12 ? 'pm' : 'am';
  const hour   = h % 12 || 12;
  return `${hour}:${m}${suffix}`;
}
